# Fresh adversarial audit of the deterministic propagation proposition

Audited source: `outputs/sk_cutoff_proof.md`, Sections 3.1–3.4 and the own-energy comparison in Sections 2 and 4. This audit read that source afresh and did not read earlier audit verdicts or numerical implementations. Review followed the paper-writing skill's integrity and review guidance. No main-file edits were made.

## Verdict and scope

I found no mathematical defect in the deterministic proposition

\[
C(\nu_0P_t)\le [1-k]^{-1},\qquad
k=\|B\|_{\rm op}+(2e^{4M}+e^{8M})\max_i\sum_jB_{ij}^2<1,
\]

for a product initial law, symmetric zero-diagonal finite real interaction matrix, and arbitrary finite external fields. I independently reconstructed the differentiation identity, signed estimate, completion of squares, eigenvalue comparison, and approximation from singular products. Numerical checks were adversarial checks of the finite-state algebra and endpoint behavior; they do not prove a uniform asymptotic claim.

This audit did not independently verify the external local-product cutoff theorem, Wang's theorem, bibliographic priority, or the larger SK conclusion. Those are separate dependencies. This is an internal mathematical audit, not an external peer-review certification.

## Independent reconstruction

### 1. Rate normalization and an edge formula

For an undirected coordinate edge \(\{x,y\}\), write \(p=\nu(x)\), \(q=\nu(y)\), and \(\Delta=f(x)-f(y)\). Its contribution to the own conditional-variance energy is

\[
\frac{pq}{p+q}\Delta^2.
\]

This follows by adding the two endpoint contributions to the conditional variance, so there is no additional factor two. Along a differentiable law the derivative of that edge contribution, with \(f\) fixed, is

\[
\frac{q^2\dot p+p^2\dot q}{(p+q)^2}\Delta^2.
\]

The target flip rate is \(r_i(x)=(1-x_i n_i(x))/2\). Accordingly, \(\Gamma f(x)=\frac12\sum_i r_i(x)[f(x^i)-f(x)]^2\), which is exactly the manuscript's \(\sum_i(1-x_i n_i)(\partial_i f)^2\). For one spin, the sum of its two off-diagonal rates is one: the nonzero decay rate is exactly one.

### 2. Differentiating the own energy

Let \(Q_i\) be conditional expectation under the actual current law. Differentiating \(\nu[(f-Q_if)^2]\) creates a term involving \(\dot Q_if\). That function is independent of \(x_i\), even for an arbitrary non-Ising law, and hence is orthogonal to \(D_if=f-Q_if\) under \(\nu\). The term vanishes exactly.

For a centered extremizer, \(\sum_iD_if=f/C\). Subtracting \(C E'\) from \(V'\), the terms involving \(fLf\) cancel, leaving

\[
V'-CE'=2A-2C\sum_i\nu\Gamma(D_if)
+2C\sum_i\nu[D_if\,LQ_if].
\]

The first sum is \(A+T\). For \(j\ne i\), \(\partial_jQ_if\) is independent of \(x_i\); flipping coordinate \(j\) does not change this independence. Since \(\partial_if\) is also independent of \(x_i\), the remaining conditioning step is

\[
\nu[(x_i-m_i)(n_j-x_j)\mid x_{-i}]
=(1-m_i^2)\partial_i n_j.
\]

This yields exactly

\[
V'-CE'=-2(C-1)A-2CT+2CS.
\]

No target-equilibrium identity is applied to the evolving law, and no independent-coupling assumption is applied after conditioning on a configuration.

### 3. Target derivative, arbitrary field size, and preservation of signs

The integral representation for \(\partial_i n_j\) follows directly from the finite difference of tanh. The bound \(|(\log\operatorname{sech}^2)'|\le2\) gives its stated relative variation bound on an interval of length \(2|B_{ij}|\). The remainder constant is \(\int_0^1 4r\,dr=2\), not four. The relative form remains valid for arbitrarily large finite local fields; no lower bound on \(s_j=1-n_j^2\) is required.

For \(v=1-m^2\), \(s=1-n^2\), and \(w=1-mn\), the pointwise inequality

\[
v^2+s^2\le v+s=2-m^2-n^2\le2(1-mn)=2w
\]

uses only \((m-n)^2\ge0\). It is therefore valid for opposing biases as well as nearly deterministic aligned biases. With \(u_i=v_i a_i\), \(z_i=s_i a_i\), the signed form is bounded by

\[
|u^TBz|\le\frac{\|B\|}{2}(\|u\|^2+\|z\|^2)
\le\|B\|\sum_i w_i a_i^2.
\]

The error uses \(B_{ij}^2\). Symmetry of \(B\) is relevant here: it makes \(B\circ B\) symmetric, with operator norm bounded by its maximal row sum \(R\). This justifies the exact coefficient in the \(S_0\) bound.

### 4. The residual square and its coefficient

Weighted Cauchy–Schwarz uses the same positive weight \(1-x_jn_j\) that occurs in \(T\). It is strictly positive for finite fields. Moreover,

\[
\frac{s_j^2}{1-x_jn_j}=s_j(1+x_jn_j)\le2.
\]

Together with \(v_i^2\le2w_i\), this gives \(U\le4e^{8M}RA\), and therefore \(|S_1|\le2e^{4M}\sqrt{RAT}\). The completion

\[
-T+2e^{4M}\sqrt{RAT}
=-(\sqrt T-e^{4M}\sqrt{RA})^2+e^{8M}RA
\]

recovers the claimed coefficient \(2e^{4M}+e^{8M}\) in \(k\), with no factor-of-two discrepancy.

### 5. Barrier, multiplicities, and singular products

For a full-support law on a finite connected cube, the own chain has a strictly positive gap. On a compact time interval starting from a full-support law, its symmetrization is a smooth symmetric matrix with a one-dimensional zero eigenspace. Its first positive eigenvalue is locally Lipschitz, as is its reciprocal. At differentiability points the derivative of the extremal quotient is obtained from an extremizer; at a repeated eigenvalue the one-sided envelope derivative is controlled by the maximum over the extremizer space. The same estimate holds for every such extremizer.

The coefficient multiplying \(A/E\) in the derivative bound is nonpositive only when \(C\ge C_*\). The manuscript uses \(A/E\ge1/2\) only in that region, so the direction of the inequality is correct. The positive-part or barrier argument then prevents a product-start constant \(C(0)=1\) from crossing \(C_*\).

Finally, \(pq/(p+q)\), extended by zero when \(p+q=0\), is continuous on the nonnegative quadrant. This gives continuity of the own energy under approximations of singular product laws, including point masses. The extension concerns the Poincaré inequality rather than a possibly ill-defined reciprocal gap of the singular law. For every positive time the actual target chain has full support.

The energy comparison \(E\le2A\) also checks directly from \(1-m^2\le2(1-mn)\), so the local Poincaré constant produced by this argument is \(2C_*\), as written.

## Independently implemented adversarial checks

The implementation is `work/fresh_counterexample_probe.py`; the complete machine-readable output is `work/fresh_counterexample_probe.json`. It uses NumPy only. Its quotient derivative uses the undirected edge formula above, separately from the right side of identity (15). The own gap is computed by a symmetric eigenproblem. Endpoint laws are evolved by positive Poisson uniformization, avoiding cancellation in tiny probabilities.

Reproduction:

```sh
python3 work/fresh_counterexample_probe.py
```

Seed: 93023071.

| Check | Cases and result |
|---|---|
| Arbitrary full-support laws | 500 cases, dimensions 2–6 |
| Law families | 100 each: unstructured log weights, biased products, noisy parity laws, correlated two-well laws, and almost-two-atom laws |
| Signed target interactions | Random symmetric matrices, operator norms sampled from 0.01–0.7; the identity tests do not require \(k<1\) |
| External fields | Coordinates bounded by 12 in absolute value, including zero-field cases |
| Strongly correlated cases | Largest tested own Poincaré constant approximately \(3.34\times10^7\) |
| Tiny masses | Smallest arbitrary-law probability approximately \(3.87\times10^{-26}\) |
| Identity (15) | Maximum relative residual \(7.22\times10^{-14}\) |
| Eigenvector equation | Maximum Euclidean residual \(7.78\times10^{-15}\) |
| Direct quotient versus reciprocal numerical gap | Maximum relative discrepancy \(1.06\times10^{-8}\), associated with ill-conditioning; the derivative check uses the direct quotient |
| Bound (24) | No positive normalized excess; largest excess was \(-0.0307\) |
| Signed \(S_0\) estimate | Largest tested ratio to its bound: 0.8671 |
| \(U\) estimate | Largest tested ratio to its bound: 0.1699 |
| Relative target derivative remainder | Largest tested ratio to its bound: 0.9616 |
| Relative target derivative magnitude | Largest tested ratio to its bound: 0.9799 |
| Actual evolving endpoint laws | 300 cases, dimensions 2–7, product and literal point-mass starts, times 0.01, 0.1, 0.5, 2, 10 |
| Endpoint interaction regimes | Matrices scaled to \(k\in\{0.1,0.3,0.6,0.9,0.99\}\) |
| Endpoint bound | No violation; largest \(C(\nu_t)(1-k)\) was 0.9831405 |
| Endpoint gap range | Largest observed \(C(\nu_t)\) was 1.41582 |
| Tiny endpoint mass | Smallest probability approximately \(2.50\times10^{-21}\) |

The endpoint target fields in this batch were bounded by four; the arbitrary-law identity batch tested fields up to twelve. Dimension and sample limits are explicit: these checks cannot exclude a higher-dimensional counterexample on their own. The conclusion rests on the reconstructed inequalities, with the finite-state calculations serving as an independent error detector.

## Findings

- **Must fix within the assigned deterministic proposition:** none found.
- **Should fix within this scope:** no substantive repair required. In a polished proof, retaining the explicit phrase that \(A/E\ge1/2\) is used only when \(C\ge C_*\) is helpful; the current text already does so.
- **Independent dependencies left outside this audit:** external local-product theorem and its normalization, SK disorder inputs, and the claimed complete cutoff conclusion.
