# Fresh adversarial audit of Section 3

Audit target: `outputs/sk_cutoff_proof.md`, read on 2026-09-23. This audit reconstructs the deterministic argument from its definitions. It does not use the manuscript's statements about previous audits as evidence. Scope: the exact differentiation identity, the signed interaction and error estimates, their constants, and the passage to the uniform Poincaré inequality. External citations, novelty, and Sections 4–7 were not independently source-checked in this audit.

## Finding

I found **no mathematical defect in Section 3**. In particular, the evolving conditional expectation contributes no missing derivative term, conditioning in the source term is legitimate under an arbitrary full-support law, the signed matrix estimate does not presume independence of its vector entries, and the factor multiplying the row-square bound is exactly `2 exp(4M) + exp(8M)` with the stated rate-one clock. This conclusion rests on the derivation below; finite-state calculations provide only supplementary checks.

## 1. The exact identity reconstructed

Write `p_t(x)=nu_t(x)` and fix a time with all `p_t(x)>0`. For the derivative at that time, keep `f` fixed and center it only at that time. Then

\[
(\operatorname{Var}_{\nu_t}f)'=\nu Lf^2,
\]

because the derivative of `(nu_t f)^2` vanishes at a centered `f`.

The energy is

\[
E(t)=\sum_i\nu_t(f-Q_i(t)f)^2.
\]

Its derivative contains both a change-of-measure term and a change-of-integrand term:

\[
E'=\sum_i\nu L(D_i f)^2
 -2\sum_i\nu[D_i f\,\dot Q_i f].
\]

For fixed `f`, `Q_i(t)f` and its time derivative are functions of `x_{-i}` alone. Conditional centering of `D_i f` therefore kills the second sum. This argument is valid for non-Ising laws and requires neither a product law nor a density relative to the target Gibbs law.

Since `Gamma g = (1/2)Lg^2-gLg`, expansion gives

\[
\begin{aligned}
V'-CE'
={}&2\nu[fLf]+2A
 -2C\sum_i\nu[D_i f\,L(f-Q_i f)]
 -2C\sum_i\nu\Gamma(D_i f)\\
={}&2A-2C\sum_i\nu\Gamma(D_i f)
 +2C\sum_i\nu[D_i f\,LQ_i f],
\end{aligned}
\]

where the cancellation uses exactly `sum_i D_i f = f/C`. No commutation of `L` and `Q_i` was made.

For the diagonal energy terms, `partial_i Q_i f=0`, so `partial_i D_i f=partial_i f`. Hence `sum_i nu Gamma(D_i f)=A+T` with no factor of two missing.

For the source, the `j=i` summand vanishes. If `j != i`, both `partial_i f` and `partial_j Q_i f` are independent of `x_i`. On a two-point conditional fiber every function `g` satisfies

\[
\nu[(x_i-m_i)g\mid x_{-i}]=v_i\partial_i g.
\]

Applying this with `g=n_j-x_j` gives `v_i partial_i n_j`; the `x_j` term is constant on that fiber. Thus the source is precisely `S`. This proves

\[
V'-CE'=-2(C-1)A-2CT+2CS.
\]

An additional diagnostic is useful: for an arbitrary centered `f` which is *not* an extremizer, the right-hand side must contain the residual

\[
2\nu\big[(f-C\sum_iD_i f)Lf\big].
\]

The stated identity avoids this residual for the correct reason, namely the exact extremizer equation (10).

## 2. Relative derivative estimate

For `u=b_j+sum_l B_{jl}x_l` and `i != j`, the field after flipping `i` is `u-2 B_{ij}x_i`. Therefore

\[
\partial_i n_j=B_{ij}\int_0^1\operatorname{sech}^2(u-2rB_{ij}x_i)\,dr.
\]

The logarithmic derivative of `sech^2` is `-2 tanh`, of absolute value at most two. Every integrand is at most `exp(4M) s_j`. Its difference from `s_j` is at most `4r |B_{ij}| exp(4M) s_j`. Integration in `r` produces the factor two, proving

\[
|\partial_i n_j-B_{ij}s_j|
\le 2e^{4M}B_{ij}^2s_j,
\qquad
|\partial_i n_j|\le e^{4M}|B_{ij}|s_j.
\]

These estimates remain valid for negative couplings and large external fields. Their proof never approximates `tanh` by its value near zero. Although `partial_i n_j` is independent of `x_i`, the principal approximation `B_{ij}s_j` need not be; the error term compensates for that dependence. Nothing later requires the error to be independent of `x_i`.

## 3. Signed source and constants

Conditional averaging of `Gamma f` gives `A=nu sum_i w_i a_i^2`, since `a_i` and `n_i` are independent of `x_i`. The pointwise bound

\[
v_i^2+s_i^2\le v_i+s_i
=2-m_i^2-n_i^2\le2(1-m_in_i)=2w_i
\]

follows from `v_i,s_i in [0,1]` and `(m_i-n_i)^2>=0`.

With `u_i=v_i a_i`, `z_i=s_i a_i`, symmetry of `B` identifies the principal source as `u^T B z`. The bound

\[
|u^TBz|\le K\|u\|\|z\|
\le\frac K2(\|u\|^2+\|z\|^2)
\le K\sum_iw_i a_i^2
\]

is pointwise. It places no independence or deterministic-coordinate requirement on `u,z`; their full configuration dependence is harmless.

The matrix `H=(B_{ij}^2)` is symmetric and nonnegative, with maximum row sum `R`. Therefore `||H||_2<=R`. Applied to `|u|,|z|`, the same estimate bounds the absolute error source by `2 exp(4M) R sum_i w_i a_i^2`. Integrating yields exactly (22).

For the subtracted source, weighted Cauchy–Schwarz is valid because each rate weight `r_j=1-x_j n_j` is strictly positive at finite fields. It yields `|S_1|^2<=TU`. The denominator is controlled by the exact identity

\[
\frac{s_j^2}{1-x_j n_j}=s_j(1+x_jn_j)\le2.
\]

Thus

\[
U\le2e^{8M}\sum_i\nu[v_i^2a_i^2]\sum_{j\ne i}B_{ij}^2
\le2e^{8M}R\nu\sum_i v_i^2a_i^2
\le4e^{8M}RA.
\]

The last bound uses `v_i^2<=2w_i`. Hence `|S_1|<=2 exp(4M) sqrt(RAT)`, exactly as stated. In the differentiation identity this becomes `4C exp(4M) sqrt(RAT)`. Combining it with `-2CT` gives

\[
-2CT+4Ce^{4M}\sqrt{RAT}
=2C[-T+2e^{4M}\sqrt{RAT}]
\le2Ce^{8M}RA.
\]

Consequently the coefficient in (24) is

\[
k=K+(2e^{4M}+e^{8M})R.
\]

There is no omitted extra factor two. The use of `||B||_op`, rather than `||(|B_{ij}|)||_op`, is justified because only the Taylor remainder is absolutized entry by entry.

## 4. Eigenvalue regularity and singular starts

For a full-support initial law and fixed finite `N`, choose a fixed complement of the constant functions, for example the functions vanishing at one distinguished vertex. On that space, the variance and own-energy forms are smooth positive-definite matrices on every compact time interval. The largest generalized Rayleigh quotient is therefore locally Lipschitz. Its upper right derivative is bounded by the largest frozen-extremizer derivative; multiplicity of the eigenvalue introduces no uncontrolled term. Centering an extremizer changes neither quadratic form.

Because `v_i<=2w_i`, one has `A>=E/2`. When `C>=C_*`, the coefficient `(1-k)C-1` is nonnegative, so substituting that inequality into the *negative* term in (24) has the stated direction and gives

\[
C'\le-(1-k)(C-C_*).
\]

Since `k>=0` and `k<1`, `C_*>=1`; a full-support product initial law starts at `C=1`. Absolute continuity plus the positive-part argument prevents a crossing above `C_*`.

The singular-law limiting argument is also correct. On each unoriented edge, the energy contribution is

\[
\frac{pq}{p+q}(f(x)-f(x^i))^2.
\]

The coefficient extends continuously by zero at `p=q=0`, since `0<=pq/(p+q)<=min(p,q)`. This permits passage from full-support product initial laws to all product laws. Finite target fields make every update outcome have positive probability, so from any initial probability law `nu_0 P_t` has full support for every `t>0`. At `t=0` only the Poincaré inequality is claimed for singular starts, not a nonexistent full-support spectral quotient.

One optional exposition improvement is to state the fixed-complement argument explicitly in Section 3.4. It fills in a finite-dimensional regularity detail but does not repair a mathematical gap.

## 5. Independent finite-state challenge

I wrote a new program, `work/fresh_identity_numeric.py`, with a fresh seed and without reading existing verification programs. It generated 400 arbitrary full-support laws on cubes of dimensions 2 through 6, with random log-weights, mixed signed symmetric target couplings, and nonzero external fields. It found each law's own heat-bath extremizer by diagonalizing the independently assembled selfadjoint matrix.

To avoid merely reproducing (13), it computed the energy derivative independently by differentiating the edge coefficient `pq/(p+q)` using `p'=pL`. That derivative was compared with `sum_i nu L(D_i f)^2`. The maximum normalized discrepancy was `3.65e-16`. The maximum normalized discrepancy in (15) was `3.38e-15`. The program separately checked (17), (22), (23), and (24), and found no positive excess over any bound in those cases.

These calculations are consistent with the exact algebra above. They cannot establish the asymptotic theorem, exclude every possible implementation defect, or verify the cited external window and mixing results.

## Handoff

No mandatory correction to Section 3 identified. The claimed deterministic propagation inequality follows from the stated assumptions and the displayed estimates. This audit does not certify literature priority, external-reference accuracy, or the complete paper; those remain separate review scopes.
