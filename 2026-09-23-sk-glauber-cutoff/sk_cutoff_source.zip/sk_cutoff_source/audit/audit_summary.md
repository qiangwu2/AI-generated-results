# Fresh audit of the SK cutoff proof

Date: September 23, 2026.

**Finding:** I found no remaining mathematical gap in the revised proof of quenched worst-case total-variation cutoff for every fixed \(0<\beta<1/3\), at zero external field, in continuous time with rate one per site. The accompanying PDF is the revised manuscript for the requested separate audit.

This finding follows a fresh review by the main agent and three agent reviewers with distinct assignments, followed by review of the LaTeX transcription. It is an audit result, not a formal proof certificate or independent human peer review.

## What was checked

| Claim | Location in PDF | Audit focus |
|---|---|---|
| Exact evolution identity | Lemma 2.2, equation (2.9) | Differentiating time-dependent conditional expectations; centering; every sign and factor of two |
| Relative derivative estimates | Lemma 2.3 | Arbitrarily large local fields; signed couplings; exponential remainder constants |
| Interaction estimate | Section 2.4, equations (2.16)–(2.19) | Preserving the signed matrix norm; weighted Cauchy–Schwarz; exact square completion |
| Propagation of the own Poincaré constant | Proposition 2.1 and Section 2.5 | Repeated eigenvalues; a fixed vector space for the quotient; the invariant region; singular product starts |
| Bounded mixing window | Lemma 3.1 and equation (3.3) | The moving-reference chi-square derivative; absolute continuity at time zero; overlap normalization; worst-case quantifiers |
| Divergence of the mixing time | Section 4 | Spectral Jensen inequality; disorder-dependent test observable; endpoint and equilibrium variance bounds |
| SK specialization | Section 5 | Matrix normalization; a single disorder event; threshold \(2\beta+3\beta^2<1\); positivity before dividing by the lower bound |
| Clock normalization | Section 5.1 and Appendix A | Rate one per site versus one update per step; independent-spin profile and discrete benchmark |

## Revisions made for this audit

The theorem and numerical constants are unchanged from the preceding proof. The manuscript now supplies a fixed-complement argument for the variational envelope at eigenvalue multiplicities and a direct finite-state proof of chi-square contraction. The singular-reference argument uses an explicit positive-time limit. An optional sentence suggesting arbitrary regularization of both laws was removed: such a regularization does not automatically preserve the assumed Poincaré bound with the same constant.

The two orientations of chi-square divergence, the unordered-edge energy formula, and the eventual positivity needed for the cutoff ratio are explicit. The appendix identifies \(\beta=0\) as the independent-spin case.

## Numerical attempts to find a counterexample

These checks supplement the mathematical audit; they are not used as proof.

- One newly written implementation tested 400 arbitrary full-support laws in dimensions 2–6. The maximum normalized residual in the exact identity was \(3.38\times10^{-15}\). Independently differentiating edge conductances gave a maximum energy-derivative discrepancy of \(3.65\times10^{-16}\).
- A second implementation tested 500 arbitrary laws in dimensions 2–6, including highly biased and strongly correlated laws. The maximum relative identity residual was \(7.22\times10^{-14}\); no tested estimate failed.
- The second implementation also tested 300 evolved endpoint laws in dimensions 2–7, from product laws and literal point masses. No propagation bound failed. The largest observed ratio \(C(\nu_t)(1-k)\) was approximately \(0.9831404\).

The source bundle includes both programs, the detailed second-program results, and the three audit reports. Equation numbers in those reports refer to the earlier Markdown proof; the table above maps the main checks to the PDF.

## External inputs

The finite-state local-product argument is attributed to [Pedrotti and Salez, version 1](https://arxiv.org/abs/2607.05345v1); its needed chi-square and overlap calculations are included in full in the manuscript.

The SK matrix estimates and the additional logarithmic upper-order bound are taken from [Wang, version 2](https://arxiv.org/abs/2608.22159v2), Lemma 3.5 and Theorem 1.1, respectively. The cited statements and their clock normalization were checked against the primary source. The logarithmic upper-order bound is not needed for the bounded-window-to-cutoff-ratio implication.

## Scope

The manuscript proves a bounded window in the stated continuous-time clock and cutoff in probability over the disorder. It does not identify the positive-temperature leading constant, a deterministic center accurate to order one, or a limiting profile. It does not claim the threshold \(\beta<1/2\) or cutoff at arbitrary positive inverse temperature.

## Document verification

The final 10-page PDF compiled with TeX Live without LaTeX warnings, undefined references, or overfull boxes. Every final page was rendered and visually inspected. The shared template style was preserved, and the manuscript integrity validator passed.
