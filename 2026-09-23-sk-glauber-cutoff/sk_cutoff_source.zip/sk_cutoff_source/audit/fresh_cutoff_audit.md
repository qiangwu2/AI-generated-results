# Fresh independent audit of `sk_cutoff_proof.md`

Audited 2026-09-23. This review read the current proof directly, without using earlier audit verdicts. The focus was the eigenvalue/envelope argument, invariant region, singular starts, worst-case quantifiers, lower bound, beta-zero clock check, and primary-source verification. The main output was not edited.

## Verdict

**No blocking mathematical gap was found in the parts audited.** The proof supports the stated cutoff ratio and the displayed bounded window for every fixed \(0<\beta<1/3\), conditional on the deterministic estimates established in §§3.1–3.3. I also rechecked those estimates algebraically rather than simply assuming their conclusion; I found their conditioning, relative derivative bounds, and square completion consistent.

The theorem does not identify a positive-temperature leading constant or profile; the existing scope paragraph correctly preserves that limitation. This is an independent mathematical review, not a formal proof certificate.

## Must fix

None identified.

## Small clarifications worth making before publication

1. **Make the fixed vector space in §3.4 explicit.** The two quadratic forms have the same constant kernel, while the space of functions centered under the evolving law changes with time. The existing conclusion is correct, but one sentence saying that the generalized quotient is considered on a fixed complement of the constant functions would remove a possible concern. A complete justification is given below.
2. **Name the two divergences in §4.** The phrase “their two chi-square divergences” should be expanded to \(\chi^2(\eta P_s\Vert\nu P_s)\) and \(\chi^2(\eta P_s\Vert\mu)\). This prevents any ambiguity about the direction of the divergence or which measure supplies the Poincaré inequality. The current calculation has the correct direction.
3. **State “for sufficiently large \(N\)” before the ratio bound in §6.** For fixed \(\varepsilon\), its denominator is eventually positive. Earlier finite-\(N\) lower bounds remain valid when their right-hand sides are negative, but division by that lower bound requires eventual positivity. The limiting argument already implicitly uses this fact; it is not a defect in the conclusion.
4. **Specify “undirected edge” in the energy-continuity sentence.** The displayed \(pq/(p+q)\) contribution is correct when each \(i\)-edge is counted once. This is the natural reading of the text and agrees with the own heat-bath energy.

These are precision improvements, not repairs to a failed argument.

## Detailed checks

### 1. Rayleigh-quotient differentiation and eigenvalue multiplicity

For fixed finite \(N\), choose once and for all a reference state \(x_0\), and let \(H=\{f:f(x_0)=0\}\). Constants have been removed without imposing a time-dependent centering condition. When \(\nu_t\) has full support, both the variance and energy forms are positive definite on \(H\). In particular, \(E_t(f)>0\) for nonzero \(f\in H\): vanishing energy forces all adjacent values of \(f\) to agree, hence \(f\) is constant on the connected cube.

On the Euclidean unit sphere in \(H\), set \(R(t,f)=V_t(f)/E_t(f)\). On any compact time interval on which the law has full support, \(R\) and its time derivative are continuous, and the denominator is uniformly bounded away from zero. Consequently

\[
C(t)=\max_{f\in H,\ \|f\|_2=1}R(t,f)
\]

is locally Lipschitz. The right envelope derivative is

\[
D^+ C(t)=\max_{f\in\operatorname{argmax}R(t,\cdot)}
\frac{V_t'(f)-C(t)E_t'(f)}{E_t(f)}.
\]

Here one may replace an active \(f\) by \(f-\nu_t f\), since the numerator and denominator forms, and their derivatives with \(f\) held fixed at the time under consideration, are invariant under adding a constant. The centered eigenvector identity (10) then applies. Thus the multiplicity at the initial product law, where the gap eigenvalue commonly has multiplicity \(N\), does not invalidate the derivative argument.

For fixed \(f\), the mean-square derivative in the variance vanishes at the centering time. For the energy, the additional derivative of \(Q_i f\) is independent of \(x_i\), hence orthogonal under \(\nu_t\) to \(D_i f\). This verifies (13), including the fact that \(Q_i\) depends on time.

The exact identity (15) is consistent: use \(\sum_iD_i f=C^{-1}f\) only after expanding \(E'\), then separate the \(j=i\) carré-du-champ contributions. In the remaining cross term, \(\partial_j Q_i f\) is indeed independent of \(x_i\), so the conditional identity producing \(v_i\partial_i n_j\) is valid under an arbitrary full-support law.

### 2. Interaction estimate and invariant region

The relative expansion (17) uses the field at the actual configuration, not a small-field approximation. Since 

\[
\left|\frac{d}{du}\log\operatorname{sech}^2u\right|\le2,
\]

the exponential factors handle large fields as claimed. The coefficient \(2e^{4M}\) in the remainder follows by integrating \(4r|B_{ij}|e^{4M}s_j\) over \(r\in[0,1]\) and then multiplying by \(|B_{ij}|\).

The principal bilinear form is evaluated pointwise, so the dependence of \(v_i,s_i,a_i\) on the configuration does not obstruct the signed operator-norm bound. Symmetry of \(B\) also ensures that \(B\circ B\) has operator norm at most the maximum row sum \(R\). The inequality \(v_i^2+s_i^2\le2(1-m_i n_i)\) is valid for all \(m_i,n_i\in[-1,1]\).

For the cross remainder, the denominator \(1-x_jn_j\) is strictly positive for finite fields, and

\[
\frac{(1-n_j^2)^2}{1-x_jn_j}
=(1-n_j^2)(1+x_jn_j)\le2.
\]

This gives \(U\le4e^{8M}RA\) and then the displayed completion of squares. No disorder-dependent independence assumption is introduced.

From (24), divide by \(E\). When \(C\ge C_*=(1-k)^{-1}\), the bracket has nonnegative sign, so using \(A/E\ge1/2\) has the correct inequality direction and gives (25).

For a rigorous invariant-region argument, let \(g(t)=(C(t)-C_*)_+\). It is absolutely continuous on every finite interval. Almost everywhere on its positive set, \(g'\le-(1-k)g\); almost everywhere on its zero set, \(g'=0\). Thus \(g'\le-(1-k)g\) almost everywhere. A full-support product start has \(C(0)=1\le C_*\), and Grönwall yields \(g\equiv0\). No differentiability of a chosen eigenvector is needed, and a tangency at the boundary cannot produce an escape.

### 3. Singular product starts

Approximate each one-site marginal by a strictly positive marginal, retaining the product structure. For every approximation, the same constant \(C_*\) applies. The semigroup is a fixed finite stochastic matrix at each fixed \(t\), hence acts continuously on initial laws. Variance is continuous in the probabilities.

For an undirected coordinate edge with endpoint masses \(p,q\), the own energy contribution equals

\[
\frac{pq}{p+q}(f(x)-f(x^i))^2.
\]

The coefficient extends continuously to \((p,q)=(0,0)\) with value zero, since it is bounded by \(\min(p,q)\). Therefore the entire energy is continuous on the probability simplex, and the inequality passes to the limit for every fixed \(t,f\). Since \(t,f\) were arbitrary, no problematic exchange of uniform limits is required. The chain has strictly positive edge rates, so every initial law has full support at each \(t>0\). At \(t=0\), the inequality itself, rather than an undefined reciprocal gap at a point mass, is the proper statement; the draft states this correctly.

### 4. Local inequality, common part, and worst-case quantifiers

The comparison \(\mathcal E_\nu(f)\le2\nu\Gamma f\) is valid because \(v_i\le2(1-m_i n_i)\) after conditioning. The same local constant holds along every future segment of \(P_t(x,\cdot)\), and taking \(t\to\infty\) supplies the required equilibrium inequality.

Let \(\alpha=1-\|\nu-\mu\|_{\rm TV}\ge\varepsilon\), and let \(\eta\) be the common part divided by \(\alpha\). Both initial divergences are at most \(1/\varepsilon-1\le1/\varepsilon\). Applying contraction separately relative to \(\nu P_s\) and to \(\mu P_s=\mu\), then using the factor \(1/2\) in each TV/chi-square comparison, gives exactly (27), without an extra factor of two.

Because the finite-state worst-case distance is a maximum of finitely many continuous functions, its mixing threshold is attained. At \(t=t_{\rm mix}(1-\varepsilon)\), every starting state satisfies the common-part hypothesis. The subsequent bound is uniform in that state, so maximizing proves (28)–(29). One does not need the same starting state to maximize the distance at both times.

The high-probability disorder event controls \(k_N\) alone. The propagation proposition is deterministic on that event, simultaneously for all configurations, times, and \(\varepsilon\in(0,1/2)\). There is no union bound over initial states and no illicit post-selection independence assumption.

### 5. Diverging-time lower bound

Zero external field is used precisely where needed: \(\mu\sigma_i=0\). Reversibility makes \(-L\) positive selfadjoint, and the spectral measure of \(\sigma_i\) has total mass one. Its first moment is

\[
\langle\sigma_i,-L\sigma_i\rangle_\mu
=1-\mu n_i^2\le1.
\]

Convexity of \(e^{-2t\lambda}\) gives the stated lower bound \(\|P_t\sigma_i\|_2^2\ge e^{-2t}\). Averaging the sum of squares over the starting state under \(\mu\) implies existence of a state with \(\|u\|^2\ge Ne^{-2t}\); no simultaneous choice across times is required for worst-case TV.

Both laws have variance of \(u\cdot\sigma\) bounded by \(C_*\|u\|^2\). At the midpoint threshold, each Chebyshev error is at most \(4C_*/\|u\|^2\). Their sum produces the factor (8) in (32), and for every time strictly below the bound in (33), the distance is strictly greater than \(1-\varepsilon\). This establishes the mixing-time lower bound even though equality is allowed in the definition of the mixing threshold.

### 6. Beta-zero benchmarks

For rate-one resampling, a spin retains mean \(e^{-t}\), so the half-logarithmic center is correct. Under the uniform reference law, the log likelihood ratio has expansion

\[
\frac a{\sqrt N}\sum_i\sigma_i-\frac{a^2}2+o(1).
\]

Its second moment is \((1+a^2/N)^N\le e^{a^2}\), providing uniform integrability for the TV likelihood-ratio expression. For \(Z\sim N(0,1)\), direct evaluation of \(\tfrac12\mathbb E|e^{aZ-a^2/2}-1|\) gives \(2\Phi(a/2)-1\). Equation (37) is correct.

In discrete time, the Walsh eigenvalues \(1-k/N\) are nonnegative, and the chi-square sum in (38) has the stated normalization. The covariance of distinct coordinates is nonpositive because \((1-2/N)^r\le(1-1/N)^{2r}\), giving variance at most \(N\). At \(r=(N/2)\log N+sN\), these upper and lower bounds place every fixed mixing quantile within \(O_\varepsilon(N)\) of the center. Thus the stated order-\(N\) benchmark window is justified. The Poisson fluctuation calculation is also correct, and the SK argument uses only the explicitly justified one-sided conversion.

## Primary-source checks

**Pedrotti–Salez.** I opened the exact cited [arXiv v1 primary text](https://arxiv.org/html/2607.05345v1). Theorem 1 gives \(3/(2\gamma_*)\log(1/\varepsilon)\). Lemma 1 contracts \(\chi^2(\nu P_T\Vert\mu P_T)\) by the exponential of minus twice the integral of the evolving reference law's Poincaré constant. Finite-state heat-bath dynamics with all functions as the test algebra satisfies its regularity conditions. Substituting \(\gamma_*=(2C_*)^{-1}\) gives exactly \(3C_*\log(1/\varepsilon)\). The common-part argument in the draft has the same valid divergence orientation.

**Wang.** I opened the exact cited [arXiv v2 primary text](https://arxiv.org/html/2608.22159v2). Its interaction matrix includes beta: its off-diagonal entries have variance \(\beta^2/N\), so it corresponds to \(B=\beta J\) in this draft. Theorem 1.1 uses one uniformly selected site per discrete step and bounds worst-case mixing by \(C_\beta N\log(N/\varepsilon)\), simultaneously over external fields. Lemma 3.5's proof explicitly supplies the entry maximum, operator norm, and maximum row-square estimates required here. The draft's one-sided Poissonization conversion preserves this normalization and yields the stated continuous-time upper order.

## Claim-evidence ledger

| Claim | Evidence checked | Status |
|---|---|---|
| Quotient differentiation survives multiplicity | Fixed-complement compact maximum and envelope derivative; orthogonality in \(E'\) | Supported |
| Product starts stay in \(C\le C_*\) | Differential inequality for the absolutely continuous positive part | Supported |
| Point masses and singular products are covered | Continuous edge-energy formula and full-support approximation | Supported |
| Uniform local Poincaré inequality implies worst-case window | Common part, correctly oriented chi-square contractions, maximum over starts | Supported |
| Mixing times diverge at least as half log \(N\) | Spectral Jensen inequality and two-law linear-statistic test | Supported |
| SK parameter interval is \(\beta<1/3\) | \(k_N\le2\beta+3\beta^2+o(1)<1\) | Supported |
| Additional logarithmic upper order | Wang Theorem 1.1 plus one-sided Poissonization | Source verified |
| Beta-zero clocks and profile | Product likelihood ratio; Walsh eigenvalues and covariance calculation | Supported |

No unresolved author decision is needed for the mathematical conclusions audited here.
