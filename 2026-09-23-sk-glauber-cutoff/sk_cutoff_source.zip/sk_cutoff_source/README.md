# SK cutoff proof: source and audit bundle

The LaTeX sources in this directory generated the accompanying 10-page
sk_cutoff_proof.pdf. The main result concerns fixed 0 < beta < 1/3,
zero field, and continuous-time heat-bath dynamics at rate one per site.
Author details are intentionally unset.

## Compile

From this directory, with TeX Live or MacTeX installed:

~~~sh
LC_ALL=C LANG=C latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
~~~

The bibliography is references.bib. The supplied style.tex is the
unchanged personal template style. Paper-local notation is in
paper-macros.tex. The generated main.bbl is also included.

## Audit materials

The file audit/audit_summary.md gives the current findings and maps them to
PDF equation numbers. The other audit reports concern the preceding
Markdown proof and retain its equation numbers. The LaTeX transcription
and its expanded envelope and chi-square arguments were subsequently rechecked.

The programs in checks/ require Python 3 and NumPy. They are supplementary
finite-state diagnostics, not proofs. Run them from this directory:

~~~sh
mkdir -p work
python3 checks/fresh_identity_numeric.py
python3 checks/fresh_counterexample_probe.py
~~~

The second program writes results to work/fresh_counterexample_probe.json.
The recorded results used in the audit are under checks/results/.
