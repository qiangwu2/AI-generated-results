"""Independent finite-state challenge of the propagation proposition.

The quotient derivative is assembled from undirected edge conductances, not
from the manuscript's conditional-projection differentiation identity.
"""
import json
import numpy as np


def expit(z):
    return 1/(1+np.exp(-z))


def logsumexp(z):
    largest=np.max(z)
    return largest+np.log(np.exp(z-largest).sum())


def evolve(p, Q, t, n):
    # Positive uniformization avoids subtractive cancellation in tiny entries.
    P = np.eye(len(p))+Q/n
    mean = n*t
    weight = np.exp(-mean)
    term = p.copy()
    out = weight*term
    for r in range(1, max(100, int(mean+20*np.sqrt(mean)+100))):
        term = term@P
        weight *= mean/r
        out += weight*term
        if r > mean and weight < 1e-17:
            break
    return out/out.sum()

rng = np.random.default_rng(93023071)


def geometry(n):
    indices = np.arange(2**n)
    spins = 2*((indices[:, None] >> np.arange(n)) & 1)-1
    flips = indices[:, None] ^ (1 << np.arange(n))[None, :]
    return spins.astype(float), flips


def target(spins, flips, B, b):
    fields = spins @ B.T + b
    # The two evaluations intentionally do not use 1-tanh for rare flips.
    rates = expit(-2*spins*fields)
    means = np.tanh(fields)
    variances = 1/np.cosh(fields)**2
    Q = np.zeros((len(spins), len(spins)))
    Q[np.arange(len(spins))[:, None], flips] = rates
    Q[np.diag_indices_from(Q)] = -rates.sum(axis=1)
    return fields, rates, means, variances, Q


def gap_data(p, spins, flips):
    # -L_own conjugated into ordinary Euclidean coordinates.
    adjacent = p[flips]
    cond = adjacent/(p[:, None]+adjacent)
    H = np.zeros((len(p), len(p)))
    H[np.arange(len(p))[:, None], flips] = -np.sqrt(p[:, None]*adjacent)/(p[:, None]+adjacent)
    H[np.diag_indices_from(H)] = cond.sum(axis=1)
    vals, vecs = np.linalg.eigh(H)
    f = vecs[:, 1]/np.sqrt(p)
    f -= np.dot(p, f)
    f /= np.sqrt(np.dot(p, f*f))
    return vals[1], f, H


def edge_quotient(p, dp, f, flips):
    V = np.dot(p, f*f)-np.dot(p, f)**2
    Vdot = np.dot(dp, f*f)-2*np.dot(p, f)*np.dot(dp, f)
    E = 0.
    Edot = 0.
    for i in range(flips.shape[1]):
        left = np.flatnonzero(np.arange(len(p)) < flips[:, i])
        right = flips[left, i]
        P, R = p[left], p[right]
        delta = f[left]-f[right]
        E += np.dot(P*R/(P+R), delta*delta)
        Edot += np.dot((R*R*dp[left]+P*P*dp[right])/(P+R)**2, delta*delta)
    return V, E, Vdot, Edot


def identity_check(p, B, b):
    spins, flips = geometry(len(b))
    fields, rates, means, s, Q = target(spins, flips, B, b)
    gap, f, H = gap_data(p, spins, flips)
    dp = p@Q
    V, E, Vdot, Edot = edge_quotient(p, dp, f, flips)
    C = V/E
    m = spins*(p[:, None]-p[flips])/(p[:, None]+p[flips])
    v = 4*p[:, None]*p[flips]/(p[:, None]+p[flips])**2
    a = (f[:, None]-f[flips])/(2*spins)
    projections = (p[:, None]*f[:, None]+p[flips]*f[flips])/(p[:, None]+p[flips])
    residuals = f[:, None]-projections
    A = np.dot(p, np.sum(rates*(f[:, None]-f[flips])**2/2, axis=1))
    T = S = S0 = S1 = U = 0.
    derivative_remainder_ratio = derivative_size_ratio = 0.
    K = np.linalg.norm(B, 2)
    M = np.max(np.abs(B))
    R = np.max(np.sum(B*B, axis=1))
    for i in range(len(b)):
        for j in range(len(b)):
            if i == j:
                continue
            DjDi = (residuals[:, i]-residuals[flips[:, j], i])/(2*spins[:, j])
            DjQi = (projections[:, i]-projections[flips[:, j], i])/(2*spins[:, j])
            # Stable exact two-point target derivative.
            h = fields[:, j]-B[j, i]*spins[:, i]
            dn = np.sinh(2*B[j, i])/(2*np.cosh(h+B[j, i])*np.cosh(h-B[j, i]))
            T += np.dot(p, 2*rates[:, j]*DjDi**2)
            S += np.dot(p, v[:, i]*a[:, i]*dn*DjQi)
            S0 += np.dot(p, v[:, i]*a[:, i]*dn*a[:, j])
            S1 += np.dot(p, v[:, i]*a[:, i]*dn*DjDi)
            U += np.dot(p, dn**2*v[:, i]**2*a[:, i]**2/(2*rates[:, j]))
            if B[i,j] != 0:
                rem_bound = 2*np.exp(4*M)*B[i,j]**2*s[:, j]
                derivative_remainder_ratio = max(derivative_remainder_ratio,
                    np.max(np.abs(dn-B[i,j]*s[:, j])/rem_bound))
                derivative_size_ratio = max(derivative_size_ratio,
                    np.max(np.abs(dn)/(np.exp(4*M)*abs(B[i,j])*s[:, j])))
    k = K+(2*np.exp(4*M)+np.exp(8*M))*R
    lhs = Vdot-C*Edot
    rhs = -2*(C-1)*A-2*C*T+2*C*S
    bound = -2*((1-k)*C-1)*A
    scale = max(1., abs(lhs), abs(rhs), abs(Vdot), abs(C*Edot))
    f_residual = np.linalg.norm(H@(np.sqrt(p)*f)-gap*np.sqrt(p)*f)
    result = {
        'identity_relative_residual': float(abs(lhs-rhs)/scale),
        'quotient_vs_gap_relative_residual': float(abs(C*gap-1)),
        'eigen_residual': float(f_residual),
        'bound_normalized_excess': float((lhs-bound)/max(1., abs(lhs), abs(bound))),
        'signed_S0_ratio': float(abs(S0)/((K+2*np.exp(4*M)*R)*A)) if R else 0.,
        'U_ratio': float(U/(4*np.exp(8*M)*R*A)) if R else 0.,
        'target_remainder_ratio': float(derivative_remainder_ratio),
        'target_derivative_ratio': float(derivative_size_ratio),
        'decomposition_relative_residual': float(abs(S-S0+S1)/max(1.,abs(S),abs(S0),abs(S1))),
        'C': float(C), 'k': float(k), 'min_p': float(p.min()),
    }
    assert result['identity_relative_residual'] < 2e-7, result
    assert result['bound_normalized_excess'] < 2e-7, result
    assert result['signed_S0_ratio'] <= 1+2e-7, result
    assert result['U_ratio'] <= 1+2e-7, result
    assert result['target_remainder_ratio'] <= 1+2e-7, result
    assert result['target_derivative_ratio'] <= 1+2e-7, result
    return result


def random_interaction(n, size):
    B = rng.normal(size=(n,n))
    B = (B+B.T)/2
    np.fill_diagonal(B, 0)
    B *= size/max(np.linalg.norm(B, 2), 1e-200)
    return B


def get_k(B):
    M = np.max(abs(B))
    R = np.max(np.sum(B*B, axis=1))
    return np.linalg.norm(B,2)+(2*np.exp(4*M)+np.exp(8*M))*R


results = []
law_counts = {}
for n in range(2,7):
    spins, flips = geometry(n)
    for trial in range(100):
        B = random_interaction(n, rng.uniform(0.01, 0.7))
        b = rng.choice([0., .5, 3., 8., 12.])*rng.uniform(-1, 1, n)
        kind = trial % 5
        if kind == 0:
            logp = rng.normal(0, rng.choice([.2, 1., 4., 8.]), len(spins))
            law = 'unstructured_log_weights'
        elif kind == 1:
            logp = rng.uniform(-1,1,n)@spins.T * rng.choice([0., 1., 3., 6.])
            law = 'product_extreme_bias'
        elif kind == 2:
            logp = rng.choice([1., 3., 8.])*np.prod(spins, axis=1)
            logp += rng.normal(0, .2, len(spins))
            law = 'parity_with_noise'
        elif kind == 3:
            signs = rng.choice([-1,1], n)
            logp = rng.choice([.1, 1., 3.])*(spins@signs)**2/n
            logp += rng.normal(0, .2, len(spins))
            law = 'two_well_correlated'
        else:
            p = np.full(len(spins), .0001/(len(spins)-2))
            chosen = rng.choice(len(spins), 2, replace=False)
            p[chosen] = .49995
            logp = np.log(p)
            law = 'two_atom_nearly_singular'
        p = np.exp(logp-logsumexp(logp))
        r = identity_check(p, B, b)
        r['law'] = law
        r['n'] = n
        results.append(r)
        law_counts[law] = law_counts.get(law,0)+1

# Test semigroup endpoints directly, starting also from literal point masses.
endpoint_results = []
for n in range(2,8):
    spins, flips = geometry(n)
    for trial in range(10):
        B = random_interaction(n, rng.uniform(.04,.5))
        # Rescale to deliberately include cases near k=1.
        wanted = rng.choice([.1,.3,.6,.9,.99])
        lo, hi = 0., 5.
        for _ in range(45):
            mid = (lo+hi)/2
            if get_k(mid*B) > wanted: hi=mid
            else: lo=mid
        B *= (lo+hi)/2
        k = get_k(B)
        b = rng.choice([0., 1., 4.])*rng.uniform(-1,1,n)
        _, _, _, _, Q = target(spins, flips, B, b)
        if trial % 3 == 0:
            p0 = np.zeros(len(spins)); p0[rng.integers(len(spins))]=1.
            label='point_mass'
        else:
            h0 = rng.uniform(-1,1,n)*rng.choice([0.,1.,4.])
            lp = spins@h0
            p0 = np.exp(lp-logsumexp(lp)); label='product'
        for t in [.01,.1,.5,2.,10.]:
            pt = evolve(p0, Q, t, n)
            assert pt.min()>0
            gap, _, _ = gap_data(pt,spins,flips)
            C = 1/gap
            ratio = C*(1-k)
            assert ratio <= 1+1e-6, (n,trial,t,C,k,pt.min())
            endpoint_results.append({'n':n,'trial':trial,'t':t,'start':label,
                'k':float(k),'C':float(C),'C_over_bound':float(ratio),'min_p':float(pt.min())})

summary = {
    'seed':93023071,
    'arbitrary_law_cases':len(results),
    'arbitrary_law_families':law_counts,
    'maximum_identity_relative_residual':max(r['identity_relative_residual'] for r in results),
    'maximum_eigen_residual':max(r['eigen_residual'] for r in results),
    'maximum_quotient_vs_gap_relative_residual':max(r['quotient_vs_gap_relative_residual'] for r in results),
    'maximum_bound_normalized_excess':max(r['bound_normalized_excess'] for r in results),
    'maximum_signed_S0_ratio':max(r['signed_S0_ratio'] for r in results),
    'maximum_U_ratio':max(r['U_ratio'] for r in results),
    'maximum_target_remainder_ratio':max(r['target_remainder_ratio'] for r in results),
    'maximum_target_derivative_ratio':max(r['target_derivative_ratio'] for r in results),
    'largest_C_arbitrary_law':max(r['C'] for r in results),
    'smallest_arbitrary_probability':min(r['min_p'] for r in results),
    'endpoint_cases':len(endpoint_results),
    'maximum_endpoint_C_over_bound':max(r['C_over_bound'] for r in endpoint_results),
    'largest_endpoint_C':max(r['C'] for r in endpoint_results),
    'smallest_endpoint_probability':min(r['min_p'] for r in endpoint_results),
    'max_ratio_endpoint_case':max(endpoint_results,key=lambda r:r['C_over_bound']),
}
with open('work/fresh_counterexample_probe.json','w') as out:
    json.dump({'summary':summary,'arbitrary_laws':results,'endpoints':endpoint_results},out,indent=2)
print(json.dumps(summary, indent=2))
