import itertools, json
import numpy as np
rng=np.random.default_rng(592817)
worst={'identity_relative_error':0.,'energy_derivative_relative_error':0.,'source0_excess':-float('inf'),'source1_excess':-float('inf'),'inequality24_excess':-float('inf'),'derivative17_excess':-float('inf')}
count=0
for N in (2,3,4,5,6):
    x=np.array(list(itertools.product((-1.,1.),repeat=N)))
    d=len(x); flips=[np.arange(d)^(1<<(N-i-1)) for i in range(N)]
    for rep in range(80):
        scale=(.003,.06,.25,.7)[rep%4]
        B=rng.normal(size=(N,N))*scale; B=(B+B.T)/2; np.fill_diagonal(B,0)
        b=rng.normal(size=N)*(rep%4)
        ell=rng.normal(size=d)*(0.4,1.,2.,3.)[(rep//4)%4]
        p=np.exp(ell-ell.max()); p/=p.sum()
        n=np.tanh(x@B+b)
        q=(1-x*n)/2
        L=np.zeros((d,d)); Q=[]; m=np.empty((d,N));
        for i,ii in enumerate(flips):
            L[np.arange(d),ii]+=q[:,i]; L[np.arange(d),np.arange(d)]-=q[:,i]
            qi=np.zeros((d,d)); qi[np.arange(d),np.arange(d)]=p/(p+p[ii]); qi[np.arange(d),ii]=p[ii]/(p+p[ii]); Q.append(qi)
            m[:,i]=qi@x[:,i]
        own=N*np.eye(d)-sum(Q)
        sym=np.sqrt(p)[:,None]*own/np.sqrt(p)[None,:]
        vals,vecs=np.linalg.eigh((sym+sym.T)/2)
        C=1/vals[1]; f=vecs[:,1]/np.sqrt(p); f-=p@f
        df=np.column_stack([(f-f[ii])/(2*x[:,i]) for i,ii in enumerate(flips)])
        v=1-m*m; s=1-n*n; w=1-m*n
        D=np.column_stack([f-qi@f for qi in Q])
        A=np.sum(p[:,None]*(1-x*n)*df*df)
        E=np.sum(p[:,None]*D*D)
        pdot=p@L
        Vprime=pdot@(f*f)-2*(p@f)*(pdot@f)
        Eprime=0.
        for i,ii in enumerate(flips):
            take=np.arange(d)<ii; a=p[take]; c=p[ii[take]]; ap=pdot[take]; cp=pdot[ii[take]]
            Eprime+=np.sum(((ap*c+a*cp)/(a+c)-a*c*(ap+cp)/(a+c)**2)*(f[take]-f[ii[take]])**2)
        Eprime2=np.sum(pdot[:,None]*D*D)
        T=S=S0=S1=0.
        for i in range(N):
            for j in range(N):
                if i==j: continue
                dji=(D[:,i]-D[flips[j],i])/(2*x[:,j])
                dni=(n[:,j]-n[flips[i],j])/(2*x[:,i])
                Qif=Q[i]@f; djQi=(Qif-Qif[flips[j]])/(2*x[:,j])
                T+=p@((1-x[:,j]*n[:,j])*dji*dji)
                S+=p@(v[:,i]*df[:,i]*dni*djQi)
                S0+=p@(v[:,i]*df[:,i]*dni*df[:,j])
                S1+=p@(v[:,i]*df[:,i]*dni*dji)
                rem=np.abs(dni-B[i,j]*s[:,j])-2*np.exp(4*np.abs(B).max())*B[i,j]**2*s[:,j]
                worst['derivative17_excess']=max(worst['derivative17_excess'],float(rem.max()))
        lhs=Vprime-C*Eprime; rhs=-2*(C-1)*A-2*C*T+2*C*S
        K=np.linalg.norm(B,2); M=np.abs(B).max(); R=(B*B).sum(axis=1).max()
        k=K+(2*np.exp(4*M)+np.exp(8*M))*R
        upper=-2*((1-k)*C-1)*A
        worst['identity_relative_error']=max(worst['identity_relative_error'],abs(lhs-rhs)/(1+abs(lhs)+abs(rhs)))
        worst['energy_derivative_relative_error']=max(worst['energy_derivative_relative_error'],abs(Eprime-Eprime2)/(1+abs(Eprime)+abs(Eprime2)))
        worst['source0_excess']=max(worst['source0_excess'],(abs(S0)-(K+2*np.exp(4*M)*R)*A)/(1+A))
        worst['source1_excess']=max(worst['source1_excess'],(abs(S1)-2*np.exp(4*M)*np.sqrt(R*A*T))/(1+A+T))
        worst['inequality24_excess']=max(worst['inequality24_excess'],(lhs-upper)/(1+abs(lhs)+abs(upper)))
        count+=1
print(json.dumps({'cases':count,'worst':worst},indent=2))
